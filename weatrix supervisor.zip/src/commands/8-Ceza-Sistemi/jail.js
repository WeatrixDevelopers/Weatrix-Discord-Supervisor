const { MessageEmbed } = require("discord.js");
const { MessageButton,MessageActionRow } = require('discord-buttons');
const Discord = require("discord.js");


const jailLimit = new Map();

const ms = require("ms")
const moment = require("moment")
require("moment-duration-format")
moment.locale("tr")

const coin = require("../../schemas/coin");
const ceza = require("../../schemas/ceza");
const cezapuan = require("../../schemas/cezapuan")


const settings = require("../../configs/settings.json")
const serverSettings =require('../../models/sunucuayar')
const { red, green, Revuu, kirmiziok, revusome } = require("../../configs/emojis.json")




module.exports = {
  conf: {
    aliases: ["jail","jail"],
    name: "jail",
    help: "jail"
  },

  run: async (client,message, args, embed) => {

    if (!message.guild) return;
    let conf = await serverSettings.findOne({
      guildID: message.guild.id
  });

  if (!message.member.hasPermission(8) && !conf.jailHammer.some(x => message.member.roles.cache.has(x))) 
  {
  message.react(red)
  message.channel.send("Yeterli yetkin bulunmuyor!").then(x=>x.delete({timeout:5000})) 
  return }
  const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  if (!member) { message.channel.send( "Bir üye belirtmelisin!").then(x=>x.delete({timeout:5000}))
  message.react(red) 
  return }
  if (conf.jailRole.some(x => member.roles.cache.has(x))) { message.channel.send( "Bu üye zaten jailde!").then(x=>x.delete({timeout:5000}))
  message.react(red) 
  return }
  if (message.member.roles.highest.position <= member.roles.highest.position) return message.channel.send(embed.setDescription("Kendinle aynı yetkide ya da daha yetkili olan birini jailleyemezsin!"));
  if (!member.manageable) return message.channel.send( "Bu üyeyi jailleyemiyorum!");
  if (settings.jaillimit > 0 && jailLimit.has(message.author.id) && jailLimit.get(message.author.id) == settings.jaillimit) 
  {
  message.react(red)
  message.channel.send( "Saatlik jail sınırına ulaştın!").then(x=>x.delete({timeout:5000})) 
  return }
  await ceza.findOneAndUpdate({ guildID: message.guild.id, userID: member.user.id }, { $push: { ceza: 1 } }, { upsert: true });
  await ceza.findOneAndUpdate({ guildID: message.guild.id, userID: member.user.id }, { $inc: { top: 1 } }, { upsert: true });
  await coin.findOneAndUpdate({ guildID: member.guild.id, userID: member.user.id }, { $inc: { coin: -10 } }, { upsert: true });
  await ceza.findOneAndUpdate({ guildID: message.guild.id, userID: message.author.id }, { $inc: { JailAmount: 1 } }, {upsert: true});
  await cezapuan.findOneAndUpdate({ guildID: message.guild.id, userID: member.user.id }, { $inc: { cezapuan: 10 } }, { upsert: true });
  const cezapuanData = await cezapuan.findOne({ guildID: message.guild.id, userID: member.user.id });
  if(conf.cezapuanlog) message.guild.channels.cache.get(conf.cezapuanlog).send(`${member} üyesi \`jail cezası\` alarak toplam \`${cezapuanData ? cezapuanData.cezapuan : 0} ceza puanına\` ulaştı!`);


let cmute1 = new MessageButton().setLabel("1").setID("cmute1").setStyle("gray")
let cmute2 = new MessageButton().setLabel("2").setID("cmute2").setStyle("gray")
let cmute3 = new MessageButton().setLabel("3").setID("cmute3").setStyle("gray")
let cmute4 = new MessageButton().setLabel("4").setID("cmute4").setStyle("gray")
let iptal = new MessageButton().setLabel("X").setID("iptal").setStyle("red")

const row = new MessageActionRow()
.addComponents(cmute1, cmute2, cmute3, cmute4, iptal)

embed.setDescription(`Merhabalar ${message.author} aşağıdan cezalandırmak istediğiniz ${member} adlı kullanıcı için bir cezalandırma şekli seçiniz.
\`\`\`
1 Cinsellik, taciz ve ağır hakaret - 7 gün
2 Sunucu kurallarına uyum sağlamamak - 3 gün
3 Sesli/Mesajlı/Ekran P. DM Taciz - 5 gün
4 Dini, Irki ve Siyasi değerlere Hakaret - 30 gün


\`\`\`
Bu cezalandırma seçeneklerinden birini başlarındaki numara bulunan butonu tıklayarak seçebilirsiniz. Seçmek için toplam 1 dakika süreniz mevcuttur.
`)


    

    let msg = await message.channel.send({ components : [row], embed: embed})
    var filter = (button) => button.clicker.user.id === message.author.id; 
    let collector = await msg.createButtonCollector(filter, { time: 99999999 })
    collector.on("collect", async (button) => {
      
  if(button.id === "cmute1") {

    member.roles.set(conf.jailRole);
    message.react(green)
    
    const reason = `Cinsellik, taciz ve ağır hakaret`

    const time = 1000*60*60*24*7 ;
    const cıkaralım = time + Date.parse(new Date());
    const şuanki = moment(Date.parse(new Date())).format("LLL");
    const sonraki = moment(cıkaralım).format("LLL");
   
    await button.reply.defer()

    const penal = await client.penalize(message.guild.id, member.user.id, "JAIL", true, message.author.id, time);
    message.lineReply(`${green} ${member.toString()} üyesi, ${message.author} tarafından, \`${reason}\` nedeniyle jaillendi! \`(Ceza ID: #${penal.id})\``).then(x=>x.delete({timeout:50000}))
    message.react(green)
    if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, **${reason}** sebebiyle jaillendiniz.`).catch(() => {});
    
 
    const log = embed
      .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
      .setColor("#2f3136")
      .setDescription(`
${member.toString()} Adlı Kişiye Jail Atıldı

${Revuu} Jail Atan Kişi : ${message.author} (\`${message.author.id}\`)
${revusome} Ceza Süresi: \`7 Gün\`
${kirmiziok} Ceza atılma tarihi: \`${şuanki}\`
${kirmiziok} Ceza bitiş tarihi: \`${sonraki}\`
${kirmiziok} Ceza Sebebi: \`${reason}\`


      `)
      .setFooter(`${moment(Date.now()).format("LLL")}`)

      client.channels.cache.get(client.channels.cache.find(x => x.name == "jail-log").id).wsend(embed)
  
      if (settings.jaillimit > 0) {
        if (!jailLimit.has(message.author.id)) jailLimit.set(message.author.id, 1);
        else jailLimit.set(message.author.id, jailLimit.get(message.author.id) + 1);
        setTimeout(() => {
          if (jailLimit.has(message.author.id)) jailLimit.delete(message.author.id);
        }, 1000 * 60 * 60);
      }

    }
  



    if(button.id === "cmute2") {
     
    member.roles.set(conf.jailRole);
    message.react(green)
    
    const reason = `Sunucu kurallarına uyum sağlamamak`

    const time = 1000*60*60*24*3 ;
    const cıkaralım = time + Date.parse(new Date());
    const şuanki = moment(Date.parse(new Date())).format("LLL");
    const sonraki = moment(cıkaralım).format("LLL");
   
    await button.reply.defer()

    const penal = await client.penalize(message.guild.id, member.user.id, "JAIL", true, message.author.id, time);
    message.lineReply(`${green} ${member.toString()} üyesi, ${message.author} tarafından, \`${reason}\` nedeniyle jaillendi! \`(Ceza ID: #${penal.id})\``).then(x=>x.delete({timeout:50000}))
    message.react(green)
    if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, **${reason}** sebebiyle jaillendiniz.`).catch(() => {});
    
 
    const log = embed
      .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
      .setColor("#2f3136")
      .setDescription(`
${member.toString()} Adlı Kişiye Jail Atıldı

${Revuu} Jail Atan Kişi : ${message.author} (\`${message.author.id}\`)
${revusome} Ceza Süresi: \`3 Gün\`
${kirmiziok} Ceza atılma tarihi: \`${şuanki}\`
${kirmiziok} Ceza bitiş tarihi: \`${sonraki}\`
${kirmiziok} Ceza Sebebi: \`${reason}\`


      `)
      .setFooter(`${moment(Date.now()).format("LLL")}`)

      message.guild.channels.cache.get(conf.jailLogChannel).wsend(log);
  
      if (settings.jaillimit > 0) {
        if (!jailLimit.has(message.author.id)) jailLimit.set(message.author.id, 1);
        else jailLimit.set(message.author.id, jailLimit.get(message.author.id) + 1);
        setTimeout(() => {
          if (jailLimit.has(message.author.id)) jailLimit.delete(message.author.id);
        }, 1000 * 60 * 60);
  
      }
    }


        if(button.id === "cmute3") {
          member.roles.set(conf.jailRole);
          message.react(green)
          
          const reason = `Sesli/Mesajlı/Ekran P. DM Taciz`
      
          const time = 1000*60*60*24*5 ;
          const cıkaralım = time + Date.parse(new Date());
          const şuanki = moment(Date.parse(new Date())).format("LLL");
          const sonraki = moment(cıkaralım).format("LLL");
         
          await button.reply.defer()
      
          const penal = await client.penalize(message.guild.id, member.user.id, "JAIL", true, message.author.id, time);
          message.lineReply(`${green} ${member.toString()} üyesi, ${message.author} tarafından, \`${reason}\` nedeniyle jaillendi! \`(Ceza ID: #${penal.id})\``).then(x=>x.delete({timeout:50000}))
          message.react(green)
          if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, **${reason}** sebebiyle jaillendiniz.`).catch(() => {});
          
       
          const log = embed
            .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
            .setColor("#2f3136")
            .setDescription(`
      ${member.toString()} Adlı Kişiye Jail Atıldı
      
      ${Revuu} Jail Atan Kişi : ${message.author} (\`${message.author.id}\`)
      ${revusome} Ceza Süresi: \`5 Gün\`
      ${kirmiziok} Ceza atılma tarihi: \`${şuanki}\`
      ${kirmiziok} Ceza bitiş tarihi: \`${sonraki}\`
      ${kirmiziok} Ceza Sebebi: \`${reason}\`
      
      
            `)
            .setFooter(`${moment(Date.now()).format("LLL")}`)
      
            client.channels.cache.get(client.channels.cache.find(x => x.name == "jail-log").id).wsend(embed)
        
            if (settings.jaillimit > 0) {
              if (!jailLimit.has(message.author.id)) jailLimit.set(message.author.id, 1);
              else jailLimit.set(message.author.id, jailLimit.get(message.author.id) + 1);
              setTimeout(() => {
                if (jailLimit.has(message.author.id)) jailLimit.delete(message.author.id);
              }, 1000 * 60 * 60);
        
      
          }
        }
            
            

          if(button.id === "cmute4") {
            member.roles.set(conf.jailRole);
            message.react(green)
            
            const reason = `Dini, Irki ve Siyasi değerlere Hakaret`
        
            const time = 1000*60*60*24*30 ;
            const cıkaralım = time + Date.parse(new Date());
            const şuanki = moment(Date.parse(new Date())).format("LLL");
            const sonraki = moment(cıkaralım).format("LLL");
           
            await button.reply.defer()
        
            const penal = await client.penalize(message.guild.id, member.user.id, "JAIL", true, message.author.id, time);
            message.lineReply(`${green} ${member.toString()} üyesi, ${message.author} tarafından, \`${reason}\` nedeniyle jaillendi! \`(Ceza ID: #${penal.id})\``).then(x=>x.delete({timeout:50000}))
            message.react(green)
            if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, **${reason}** sebebiyle jaillendiniz.`).catch(() => {});
            
         
            const log = embed
              .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
              .setColor("#2f3136")
              .setDescription(`
        ${member.toString()} Adlı Kişiye Jail Atıldı
        
        ${Revuu} Jail Atan Kişi : ${message.author} (\`${message.author.id}\`)
        ${revusome} Ceza Süresi: \`30 Gün\`
        ${kirmiziok} Ceza atılma tarihi: \`${şuanki}\`
        ${kirmiziok} Ceza bitiş tarihi: \`${sonraki}\`
        ${kirmiziok} Ceza Sebebi: \`${reason}\`
        
        
              `)
              .setFooter(`${moment(Date.now()).format("LLL")}`)
        
              client.channels.cache.get(client.channels.cache.find(x => x.name == "jail-log").id).wsend(embed)
          
              if (settings.jaillimit > 0) {
                if (!jailLimit.has(message.author.id)) jailLimit.set(message.author.id, 1);
                else jailLimit.set(message.author.id, jailLimit.get(message.author.id) + 1);
                setTimeout(() => {
                  if (jailLimit.has(message.author.id)) jailLimit.delete(message.author.id);
                }, 1000 * 60 * 60);
          
        
            }
          }
    


          
  if(button.id === "iptal") {
    await button.reply.defer()
    msg.delete();
  }


 })


}
};
