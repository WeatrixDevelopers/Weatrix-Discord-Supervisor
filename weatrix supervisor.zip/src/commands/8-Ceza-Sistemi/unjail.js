const { MessageEmbed } = require("discord.js");
const { MessageButton,MessageActionRow } = require('discord-buttons');
const Discord = require("discord.js");


const uncezaLimit = new Map();

const ms = require("ms")
const moment = require("moment")
require("moment-duration-format")
moment.locale("tr")

const penals = require("../../schemas/penals");



const settings = require("../../configs/settings.json")
const serverSettings =require('../../models/sunucuayar')
const { red, green, Revuu} = require("../../configs/emojis.json")




module.exports = {
  conf: {
    aliases: ["unjail","unreklam"],
    name: "unjail",
    help: "unjail"
  },

  run: async (client,message, args, embed) => {

    if (!message.guild) return;
    let conf = await serverSettings.findOne({
      guildID: message.guild.id
  });

  if (!message.member.hasPermission(8) && !conf.jailHammer.some(x => message.member.roles.cache.has(x))) 
  {
  message.react(red)
  message.channel.send( "Yeterli yetkin bulunmuyor!").then(x=>x.delete({timeout:5000})) 
  return }
  const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  if (!member) {
  message.react(red)
  message.channel.send( "Bir üye belirtmelisin!").then(x=>x.delete({timeout:5000})) 
  return }
  if (!message.member.hasPermission(8) && member.roles.highest.position >= message.member.roles.highest.position) 
  {
  message.react(red)
  message.channel.send( "Kendinle aynı yetkide ya da daha yetkili olan birinin jailini kaldıramazsın!").then(x=>x.delete({timeout:5000})) 
  return }
  if (!member.manageable) {
  message.react(red)  
  message.channel.send( "Bu üyeyi jailden çıkaramıyorum!").then(x=>x.delete({timeout:5000})) 
  if (settings.uncezaLimit > 0 && uncezaLimit.has(message.author.id) && uncezaLimit.get(message.author.id) == settings.jaillimit) 
  return }
  if (settings.uncezaLimit > 0 && uncezaLimit.has(message.author.id) && uncezaLimit.get(message.author.id) == settings.jaillimit) 
  {
  message.react(red)
  message.channel.send( "Saatlik jail sınırına ulaştın!").then(x=>x.delete({timeout:5000})) 
  return }



let cmute1 = new MessageButton().setLabel("1").setID("cmute1").setStyle("gray")
let cmute2 = new MessageButton().setLabel("2").setID("cmute2").setStyle("gray")
let iptal = new MessageButton().setLabel("X").setID("iptal").setStyle("red")

const row = new MessageActionRow()
.addComponents(cmute1, cmute2, iptal)

embed.setDescription(`Merhabalar ${message.author} aşağıdan istediğiniz jail-reklam ${member} adlı kullanıcı için bir ceza kaldırma şekli seçiniz.
\`\`\`
1 Buttona basarak jailden çıkarta bilirsiniz
2 Buttona basarak reklamdan çıkarta bilirsiniz
\`\`\`
Bu ceza kaldırma seçeneklerinden birini başlarındaki numara bulunan butonu tıklayarak seçebilirsiniz. Seçmek için toplam 1 dakika süreniz mevcuttur.
`)


    

    let msg = await message.channel.send({ components : [row], embed: embed})
    var filter = (button) => button.clicker.user.id === message.author.id; 
    let collector = await msg.createButtonCollector(filter, { time: 99999999 })
    collector.on("collect", async (button) => {
      
  if(button.id === "cmute1") {

    if (!conf.jailRole.some(x => member.roles.cache.get(x)))
    {
    message.react(red)
    message.channel.send( "Bu üye jailde değil!").then(x=>x.delete({timeout:5000})) 
    return }

    member.roles.set(conf.unregRoles);
    const data = await penals.findOne({ userID: member.user.id, guildID: message.guild.id, $or: [{ type: "JAIL" }, { type: "TEMP-JAIL" }], active: true });
    if (data) {
      data.active = false;
      await data.save();
    }
    message.react(green)
    message.lineReply(`${green} ${member.toString()} üyesinin jaili ${message.author} tarafından kaldırıldı!`).then(x=>x.delete({timeout:50000}))
    if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, jailiniz kaldırıldı!`).catch(() => {});

      const log = embed
      .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
      .setColor("#2f3136")
      .setDescription(`
      ${member.toString()} Adlı Kişinin Jaili Kaldırıldı
      
${Revuu} Jaili Kaldıran Kişi : ${message.author} (\`${message.author.id}\`)
          
          `)
          .setFooter(`${moment(Date.now()).format("LLL")}`)

          client.channels.cache.get(client.channels.cache.find(x => x.name == "unjail-log").id).wsend(embed)
        
          if (settings.uncezaLimit > 0) {
            if (!uncezaLimit.has(message.author.id)) uncezaLimit.set(message.author.id, 1);
            else uncezaLimit.set(message.author.id, uncezaLimit.get(message.author.id) + 1);
            setTimeout(() => {
              if (uncezaLimit.has(message.author.id)) uncezaLimit.delete(message.author.id);
            }, 1000 * 60 * 60);
        
          }
        }
    



    if(button.id === "cmute2") {

      if (!conf.reklamRole.some(x => member.roles.cache.get(x)))
      {
      message.react(red)
      message.channel.send( "Bu üye jailde değil!").then(x=>x.delete({timeout:5000})) 
      return }
     
      member.roles.set(conf.unregRoles);
      const data = await penals.findOne({ userID: member.user.id, guildID: message.guild.id, $or: [{ type: "REKLAM" }, { type: "TEMP-REKLAM" }], active: true });
      if (data) {
        data.active = false;
        await data.save();
      }
      message.react(green)
      message.lineReply(`${green} ${member.toString()} üyesinin Reklami ${message.author} tarafından kaldırıldı!`).then(x=>x.delete({timeout:50000}))
      if (settings.dmMessages) member.send(`**${message.guild.name}** sunucusunda, **${message.author.tag}** tarafından, reklaminiz kaldırıldı!`).catch(() => {});
  
      const log = embed
        .setAuthor(member.user.username, member.user.avatarURL({ dynamic: true, size: 2048 }))
        .setColor("#2f3136")
        .setDescription(`
        ${member.toString()} Adlı Kişinin Reklami Kaldırıldı
        
  ${Revuu} Reklami Kaldıran Kişi : ${message.author} (\`${message.author.id}\`)
            `)
            .setFooter(`${moment(Date.now()).format("LLL")}`)
            client.channels.cache.get(client.channels.cache.find(x => x.name == "unjail-log").id).wsend(embed)
        
            if (settings.uncezaLimit > 0) {
              if (!uncezaLimit.has(message.author.id)) uncezaLimit.set(message.author.id, 1);
              else uncezaLimit.set(message.author.id, uncezaLimit.get(message.author.id) + 1);
              setTimeout(() => {
                if (uncezaLimit.has(message.author.id)) uncezaLimit.delete(message.author.id);
              }, 1000 * 60 * 60);
        
            }
          }


      

          
  if(button.id === "iptal") {
    await button.reply.defer()
    msg.delete();
  }


 })
}


};
